import glob
import os

from flask import Flask, url_for, request

app = Flask(__name__)


@app.route('/')
def _():
    return "<b>Миссия Колонизация Марса</b>"


@app.route('/index')
def index():
    return "<b>И на Марсе будут яблони цвести!</b>"


@app.route('/carousel')
def carousel():
    return '''<meta charset="utf-8">
                                <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                <link rel="stylesheet"
                                href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                                integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                                crossorigin="anonymous">
                                <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />''' +\
           f''''<meta charset="utf-8">
                                <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                <link rel="stylesheet"
                                href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                                integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                                crossorigin="anonymous">
                                <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" /><title>Пейзажи Марса</title><h1 align="center">Пейзажи Марса</h1>
           <p><img src={url_for('static', filename="data/Mars.jpg")} class="rounded float-start" alt="..."></p>
           <img src={url_for('static', filename="data/Mars1.jpg")} class="rounded float-right" alt="...">
            <img src={url_for('static', filename="data/Mars2.jfif")} class="rounded float-right" alt="...">'''
# {url_for('static', filename="data/Mars1.jpg")}
@app.route('/promotion')
def promotion():
    return "<br>Человечество вырастает из детства.</br><br>Человечеству мала одна планета.</br>" \
           "<br>Мы сделаем обитаемыми безжизненные" \
           "пока планеты.</br><br>И начнем с Марса!</br><br>Присоединяйся!</br>"


@app.route('/load_image', methods=['POST', 'GET'])
def load_image():
    if request.method == 'GET':
        try:
            os.remove("static/data/kartinka")
        except Exception:
            pass
        return '''<title>Отбор астронавтов</title><h1 align="center">Загрузка фотографии</h1>
        <h3 align="center">для участии в миссии</h3>''' + f'''<!doctype html>
                            <html lang="en">
                              <head>
                                <meta charset="utf-8">
                                <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                <link rel="stylesheet"
                                href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                                integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                                crossorigin="anonymous">
                                <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                                <title>Пример формы</title>
                              </head>
                              <body>
                    
                                <div>
                                    <form class="login_form" method="post" enctype="multipart/form-data">
                                       <div class="form-group">
                                            <label for="photo">Приложите фотографию</label>
                                            <input type="file" class="form-control-file" id="photo" name="file">
                                        </div>
                                        <button type="submit" class="btn btn-primary">Отправить</button>
                                    </form>
                                </div>
                              </body>
                            </html>'''
    elif request.method == 'POST':
        f = request.files['file']
        a = f.read()
        with open("static/data/kartinka", 'wb') as imagefile:
            imagefile.write(a)
        return '''<title>Отбор астронавтов</title><h1 align="center">Загрузка фотографии</h1>
        <h3 align="center">для участии в миссии</h3>''' + f'''<!doctype html>
                            <html lang="en">
                              <head>
                                <meta charset="utf-8">
                                <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                <link rel="stylesheet"
                                href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                                integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                                crossorigin="anonymous">
                                <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                                <title>Пример формы</title>
                              </head>
                              <body>
                    
                                <div>
                                    <form class="login_form" method="post" enctype="multipart/form-data">
                                        
                                        <div class="form-group">
                                            <img width="430" src="{url_for('static', filename="data/kartinka")}" 
                   alt="здесь должна была быть картинка, но не нашлась">
                                            <input type="file" class="form-control-file" id="photo" name="file">
                                        </div>
    
                                        <button type="submit" class="btn btn-primary">Отправить</button>
                                    </form>
                                </div>
                              </body>
                            </html>'''

@app.route('/results/<nickname>/<int:level>/<float:rating>')
def results(nickname, level, rating):
    return f'''<title>Результаты</title><h1>Результаты отбора</h1><h2>Претендента на участие в миссии {nickname}:</h2>
    <div class="alert alert-success" role="alert">
               Поздравляем! Ваш рейтинг после {level} этапа отбора       
    </div>
    <h4>составляет {rating}!</h4>
    <div class="alert alert-warning" role="alert">
                      Желаем удачи!
                    </div>

'''+ '''<meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                    crossorigin="anonymous">'''


@app.route('/choice/<planet_name>')
def planet_name(planet_name):
    return f"<h1>Моё предложение: {planet_name}</h1>" \
           "<h3>Эта плнета близка к Земле;</h3>" + '''<meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                    crossorigin="anonymous"><title>Варианты выбора</title>
               ''' + '''

  <div class="alert alert-success" role="alert">
                      На ней много необходимых ресурсов;
                    </div>
  <div class="alert alert-secondary" role="alert">
                      На ней есть вода и атмосфера;
                    </div>
  <div class="alert alert-warning" role="alert">
                      На ней есть небольшое магнитное поле;
                    </div>
  <div class="alert alert-danger" role="alert">
                      Наконец, она просто красива!
                    </div>
                    '''

@app.route('/image_mars')
def image_mars():
    return f'''<h1><b><font color="black">Жди нас, Марс!</font></b></h1><title>Привет, Марс!</title><img src="{url_for('static', filename='data/MARS.jpg')}" 
                   alt="здесь должна была быть картинка, но не нашлась"><p>Вот она какая, красная планета.</p>
                   '''


@app.route('/promotion_image')
def promotion_image():
    return f'''<meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                    crossorigin="anonymous"><h1><b><font color="red">Жди нас, Марс!</font></b></h1><title>Колонизация</title><img src="{url_for('static', filename='data/MARS.jpg')}" 
               alt="здесь должна была быть картинка, но не нашлась">
               ''' + '''

  <div class="alert alert-dark" role="alert">
                      Человечество вырастет из дерева.
                    </div>
  <div class="alert alert-success" role="alert">
                      Человечеству мала одна планета.
                    </div>
  <div class="alert alert-secondary" role="alert">
                      Мы сделаем обитаемыми безжизненные пока планеты.
                    </div>
  <div class="alert alert-warning" role="alert">
                      И начнём с Марса.
                    </div>
  <div class="alert alert-danger" role="alert">
                      Присоединяйся!
                    </div>
                    '''


@app.route('/astronaut_selection')
def astronaut_selection():
    return f'''<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" /><!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                            integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                            crossorigin="anonymous">
                            <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                            <title>Пример формы</title>
                          </head>
                          <body>
                            <h1 align="center">Анкета претендента</h1>
                            <h5 align="center">На участие в миссии</h5>
                            <div>
                                <form class="login_form" method="post">
                                    <input class="form-control" placeholder="Введите фамилию" name="surname">
                                    <p><input class="form-control" placeholder="Введите имя" name="name"></p>
                                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите адрес почты" name="email">

                                    <div class="form-group">
                                        <label for="classSelect">Какое у вас образование?</label>
                                        <select class="form-control" id="classSelect" name="class">
                                          <option>Начальное</option>
                                          <option>Среднее</option>
                                          <option>Высшее</option>
                                        </select>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="prof" name="accept">
                                        <label class="form-check-label" for="acceptRules">Инженер-исследователь</label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="prof" name="accept">
                                        <label class="form-check-label" for="acceptRules">Инженер-строитель</label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="prof" name="accept">
                                        <label class="form-check-label" for="acceptRules">Пилот</label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="prof" name="accept">
                                        <label class="form-check-label" for="acceptRules">Метеоролог</label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="prof" name="accept">
                                        <label class="form-check-label" for="acceptRules">Инженер по жизнеобеспечению</label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="prof" name="accept">
                                        <label class="form-check-label" for="acceptRules">Инженер по радиационной защите</label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="prof" name="accept">
                                        <label class="form-check-label" for="acceptRules">Врач</label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="prof" name="accept">
                                        <label class="form-check-label" for="acceptRules">Экзобиолог</label>
                                    </div>

                                    <div class="form-group">
                                        <label for="form-check">Укажите пол</label>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                                          <label class="form-check-label" for="male">
                                            Мужской
                                          </label>
                                        </div>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                                          <label class="form-check-label" for="female">
                                            Женский
                                          </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="about">Почему вы хотите принять участие в миссии?</label>
                                        <textarea class="form-control" id="about" rows="3" name="about"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="photo">Приложите фотографию</label>
                                        <input type="file" class="form-control-file" id="photo" name="file">
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">Готовы остаться на Марсе?</label>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Отправить</button>
                                </form>
                            </div>
                          </body>
                        </html>'''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
